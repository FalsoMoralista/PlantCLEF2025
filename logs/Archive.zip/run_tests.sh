#!/bin/sh

python test_vision_transformer.py
